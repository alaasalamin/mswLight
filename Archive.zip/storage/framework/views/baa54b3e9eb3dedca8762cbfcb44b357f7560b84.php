<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="text-center">
        <div class="logo"></div>
        <h1 class="text-uppercase">Admin Portal</h1>
    </div>
    

</div>

    
<div class="container mt-5">
        <nav class="navbar navbar-expand-lg navbar-light bg-light my-4">
            <a class="navbar-brand">
                <?php echo e($admin); ?>

            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
              <ul class="navbar-nav">
                <li class="nav-item">
                  <a class="nav-link active" href="/home">Home <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="/admin/Partners">B2b Partners</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="/adminPanel">Control Panel</a>
                </li>
              </ul>
            </div>
          </nav>
        <div class="row">
            <div class="col-md-4 my-2">
                <div class="card">
                    <div class="text-center card-header">
                      aktive Geräte
                    </div>
                    <div class="card-body">
                      <blockquote class="blockquote mb-0">
                        
                        <table class="table table-hover">
                            <tbody>
                              
                            <?php 
                              if(sizeof($activeDevices) == 0){
                                echo "Es gibt noch keine Geräte";
                              }else{
                                ?>
                                  <?php $__currentLoopData = $activeDevices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activeDevice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  
                                        <tr>
                                          <th scope="row"><?php echo e($activeDevice->id); ?></th>
                                          <td><a class="text-decoration-none" href="admin/device/<?php echo e($activeDevice->id); ?>"><?php echo e($activeDevice->model); ?></a></td>
                                          <td><?php echo e($activeDevice->error); ?></td>
                                        </tr> 
                                  
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php
                              }
                            ?>
                              
                            </tbody>
                          </table>
                          
                      </blockquote>
                    </div>
                  </div>
            </div>
            <div class="col-md-4 my-2 justify-content-center align-items-center">

                  <div class="card">
                    <div class="card-header d-flex">
                      <?php
                          //  $keyword = $_GET['keyword'];
                      ?>
                            
                              <input placeholder="Suchgeräte" id="keyword" type="text" class="form-control text-center" >
                              <button onclick="search()" class="btn btn-primary mx-2">Suche</button>
                      
                    </div>
                  </div>
            </div>
            <div class="col-md-4 my-2">
                <div class="card">
                    <div class="text-center card-header">
                       geschlossene Geräte
                    </div>
                    <div class="card-body">
                      <blockquote class="blockquote mb-0">
                        
                        <table class="table table-hover">
                            <tbody>
                                    
                            </tbody>
                          </table>
                          
                      </blockquote>
                    </div>
                  </div>
            </div>
        </div>
    </div>

    <script>
      function search(){
        let keyword = document.getElementById('keyword').value;
        let searchLength = keyword.length;
        if(searchLength >= 1){
          location.href = 'admin/devices/search/'+keyword;
        }else{
          alert("search must be atleast 3 chars");
        }
      }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/alaaalsalameen/Desktop/lightMSW/msw/resources/views/Admin/home.blade.php ENDPATH**/ ?>