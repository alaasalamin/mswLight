<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="text-center">
        <div class="logo"></div>
        <h1 class="text-uppercase">Control Panel</h1>
    </div>
    

</div>

    
<div class="container mt-5">
        <nav class="navbar navbar-expand-lg navbar-light bg-light my-4">
            <a class="navbar-brand">
                <?php echo e($admin); ?>

            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
              <ul class="navbar-nav">
                <li class="nav-item">
                  <a class="nav-link" href="/home">Home <span class="sr-only"></span></a>
                </li>
                <li class="nav-item">
                  <a class="nav-link active" href="/adminPanel">Control Panel(current)</a>
                </li>
              </ul>
            </div>
          </nav>

          <div class="row">
              <div class="col-md-4">
                  <div class="card">
                      <div class="card-header"><h4 class="text-center">Brands</h4></div>
                      <div class="card-body">
                          <?php

                         
                                if(sizeof($brands) == 0){
                                    echo "There is no brands yet!";
                                }else{
                                    ?>

                                    <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <ul>
                                            <li><?php echo e($brand->brandName); ?> <a href="/admin/deleteBrand/<?php echo e($brand->id); ?>">Delete?</a></li>
                                        </ul>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <?php
                                }



                          ?>

                          <form action="<?php echo e(url('storeBrand')); ?>" method="POST">
                              <?php echo csrf_field(); ?>
                              <input type="text" name="brandName" class="form-control" placeholder="Apple, Samsung...">
                              <button class="btn btn-primary mt-1">Add</button>
                          </form>
                      </div>
                  </div>
              </div>
          </div>
    </div>
    <script>
      function search(){
        let keyword = document.getElementById('keyword').value;
        let searchLength = keyword.length;
        if(searchLength >= 1){
          location.href = 'admin/devices/search/'+keyword;
        }else{
          alert("search must be atleast 3 chars");
        }
      }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/alaaalsalameen/Desktop/lightMSW/msw/resources/views/Admin/controlPanel.blade.php ENDPATH**/ ?>