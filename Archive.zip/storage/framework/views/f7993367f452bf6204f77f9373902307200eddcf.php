<?php $__env->startSection('content'); ?>
<div class="container">
<div class="text-center">
        <div style="    width: 300px;
                        height: 120px;
                        background: url('../../img/logo.png') no-repeat center;
                        background-size: contain ;
                        margin-left: auto;
                        margin-right: auto;
                        margin-bottom: 10px;
                        margin-top: 20px;
        ">
           
        </div>
        <h1 class="text-uppercase">Techniker Portal</h1>
    </div>

</div>
    
<div class="container mt-5">
        <nav class="navbar navbar-expand-lg navbar-light bg-light my-4">
            <a class="navbar-brand">
                <?php echo e($admin); ?>

            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
              <ul class="navbar-nav">
                <li class="nav-item">
                  <a class="nav-link" href="/home">Home </a>
                </li>
                <li class="nav-item">
                  <a class="nav-link active" href="#"><?php echo e($device['model'] ?? ''); ?> Gerätedetails <span class="sr-only">(current)</span></a>
                </li>
              </ul>
            </div>
          </nav>
      
          <div class="row">
              <div class="col-md-8">
                  
              <div class="card">
                <div class="card-header">
                    <?php echo e($device['model']); ?> - <b><?php echo e($device['error']); ?></b>
                    <a style="float: right;"><?php echo e($device['created_at']); ?></a>
                </div>
                <div class="card-body">
                    <?php
                        $deviceId = $device['id'];
                    ?>
                <form method="POST" action="<?php echo e(url('/admin/updateDevice/'.$deviceId.'')); ?>">
            <?php echo csrf_field(); ?>

            <div class="form-group row my-2">
                <label for="brand" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Hersteller')); ?></label>

                <div class="col-md-6">

                    <input class="form-control text-center" type="text"  value="<?php echo e($device['brand']); ?>">

                    <?php $__errorArgs = ['model'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
          

   
            <div class="form-group row">

                <div class="col-md-6">
                    <input id="business" type="hidden"name="business"  value="<?php echo e($device['business']); ?>" required>

                    <?php $__errorArgs = ['id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <div class="form-group row my-2">
                <label for="description" class="col-md-4 col-form-label text-md-right"><?php echo e(__('zusätzliche Info')); ?></label>

                <div class="col-md-6">
                    <textarea   id="description" class="text-center form-control" name="description" placeholder="Vorgeschichte"><?php echo e($device['description']); ?></textarea>

                    <?php $__errorArgs = ['descriptions'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="form-group row my-2">
                <label for="deviceStatus" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Gerät startet')); ?></label>

                <div class="col-md-6 text-center">
                    <div class="deviceStatus">
                    <input class="form-control text-center" type="text"   value="<?php echo e($device['deviceStatus']); ?>">

                    </div>
                    <?php $__errorArgs = ['model'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="form-group row my-2">
                <label for="pinCode" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Sperrcode')); ?></label>

                <div class="col-md-6">
                    <input placeholder="123456" id="pinCode" type="text" class="text-center form-control <?php $__errorArgs = ['pinCode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="pinCode" value="<?php echo e($device['pinCode']); ?>" autofocus>
                    <?php $__errorArgs = ['pinCode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="form-group row my-2">
                <label for="simCode" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Sim Pin')); ?></label>

                <div class="col-md-6">
                    <input placeholder="1234" id="simCode" type="text" class="text-center form-control <?php $__errorArgs = ['simCode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="simCode" value="<?php echo e($device['simCode']); ?>" autofocus>
                    <?php $__errorArgs = ['simCode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="form-group row my-2">
                <label for="accessory" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Zubehör')); ?></label>

                <div class="col-md-6">
                    <input placeholder="Keines" id="accessory" type="text" class="text-center form-control <?php $__errorArgs = ['accessories'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="accessories"   value="<?php echo e($device['accessories']); ?>" autofocus>

                    <?php $__errorArgs = ['imei'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="form-group row my-2">
                <label for="dataRecovery" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Daten relevant?')); ?></label>

                <div class="col-md-6">
                    <div class="form-check">
                       <?php 
                            if($device['dataReovery'] == 1){
                                echo "Ja!";
                            }else{
                                echo "Nein!";
                            }
                       ?>
                    </div>

                    <?php $__errorArgs = ['dataRecovery'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="form-group row my-2">
                <label for="imei" class="col-md-4 col-form-label text-md-right"><?php echo e(__('IMEI/SN')); ?></label>

                <div class="col-md-6">
                    <input placeholder="353915102043702" id="imei"   type="text" class="text-center form-control <?php $__errorArgs = ['imei'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="imei" value="<?php echo e($device['imei']); ?>" autofocus>

                    <?php $__errorArgs = ['imei'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="form-group row">
                <label for="price" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Preisfreigabe')); ?></label>

                <div class="col-md-6">
                    <input placeholder="99€" id="price" type="text" class="text-center form-control <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="price"   value="<?php echo e($device['price']); ?>" autofocus>

                    <?php $__errorArgs = ['imei'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>


            <div class="form-group row mb-0 my-2">
                <div class="col-md-6 offset-md-4">
                    <button type="submit" class="btn btn-primary">
                        <?php echo e(__('speichern')); ?>

                    </button>
                </div>
            </div>
        </form>
                </div>
                </div>
              </div>
              <div class="col-md-4">
                  <div class="card">
                      <div class="card-header">
                      <a href="../../device/pdf/<?php echo e($device->id); ?>" class="btn btn-primary">PDF</a>
                                          </div>
                      <div class="card-body">
                      <form method="POST" action="<?php echo e(url('storeComment')); ?>">
                       <?php echo csrf_field(); ?>
                       <div class="form-group row my-2">

                            <input name="deviceId" type="hidden" value="<?php echo e($device['id']); ?>">
                            <input name="writter" type="hidden" value="<?php echo e($admin); ?>">

                           
                            <div class="col">
                                <textarea id="comment" class="text-center form-control" name="comment" placeholder="Kommentar"></textarea>

                                <?php $__errorArgs = ['comment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-check">
                        <input class="form-check-input" type="radio" name="status" id="exampleRadios1" value="readable">   
                                             <label class="form-check-label" for="flexCheckChecked">
                            Show Comment to Customer?!
                        </label>
                        </div>
                        <button type="submit" class="btn btn-primary">Kommentar!</button>
                      </form>
                      </div>
                      <?php
                        if(sizeof($comments) == 0){
                            echo "<a class='text-center m-3'>Es gibt noch keinen Kommentar</a>";
                        }else{
                          ?>    
                        
                                    <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="position-relative">
                                        <h5 class="text-center m-2"> <?php echo e($comment->writter); ?> </h5>
                                        <a class="position-absolute end-0" style="margin-right: 20px;" href="/admin/deleteComment/<?php echo e($comment->id); ?>">Delete?</a>
                                        <p class="text-center">
                                            <?php echo e($comment->comment); ?>

                                        </p>

                                        </div>                                       
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <?php
                        }
                      ?>
                  </div>  
                  <div class="card mt-2">
                      <div class="card-header">
                          <?php
                                $status = $device->status;
                          ?>
                          Device Status (<?php echo e($status); ?>)
                      </div>
                      <div class="card-body">
                          <?php
                                if($status == "finished"){
                                    echo '
                                    <a href="../../admin/openDevice/'.$device->id.'" class="btn btn-success">Open this device</a>
                                    ';
                                }else{
                                   echo '
                                   <a href="../../admin/closeDevice/'.$device->id.'" class="btn btn-danger">Close this device</a>
                                    ';
                                }
                          ?>
                      </div>
                  </div>  
              </div>
          </div>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/alaaalsalameen/Desktop/lightMSW/msw/resources/views/tech/device.blade.php ENDPATH**/ ?>