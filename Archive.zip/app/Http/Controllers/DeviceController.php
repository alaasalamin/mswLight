<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use App\Models\Brand;
use App\Models\Device;
use App\Models\Comment;
use App\Models\User;
use DB;

class DeviceController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    public function newDevice(){
        $AccountType = Auth::user()->AccountType;
        $userId = Auth::user()->id;
        $loggedInName = Auth::user()->name;
        $brands = DB::table('brands')->orderBy('brandName', 'ASC')->get();
        return view("Partner.newDevice", ["partner" => $loggedInName, "brands" => $brands]);
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //



        $createDevice = Device::create($request->all());
        $AccountType = Auth::user()->AccountType;
        $userId = Auth::user()->id;
        $loggedInName = Auth::user()->name;
        $brands = DB::table('brands')->orderBy('brandName', 'ASC')->get();
        $devices = Device::orderBy('id', 'DESC')->get();
        $deviceID = $devices[0]['id'];
        if($createDevice){
            return redirect('device/'.$deviceID.'');
        }

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $deviceDetails = Device::find($id);
        $AccountType = Auth::user()->AccountType;
        $userId = Auth::user()->id;
        $loggedInName = Auth::user()->name;
        $comments = Comment::where("deviceId", $id)->where("status", "readable")->orderBy("id", "DESC")->get();
        return view("Partner.device", ["device" => $deviceDetails, "partner" => $loggedInName, "comments" => $comments]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $device = Device::find($id);
        $device->update($request->all());     
        $loggedInName = Auth::user()->name;  
        return redirect('device/'.$id.'');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        return Device::destroy($id);
    }

    public function search($keyword){

        $userId = Auth::user()->id;
        $loggedInName = Auth::user()->name;

        $accountType = Auth::user()->AccountType;

        if($accountType == "admin"){
            $results = Device::where('id', $keyword)
            ->orWhere('model', 'like', '%'.$keyword.'%')
            ->orWhere('error', 'like', '%'.$keyword.'%')
            ->orWhere('imei', $keyword)->where('business', $userId)
            ->orderBy('id', 'DESC')->get();
            return view("admin.search", ["devices" => $results, "partner" => $loggedInName, "keyword" => $keyword]);
       
        }elseif($accountType == "partner"){
            $results = Device::where('id', $keyword)->where('business', $userId)
            ->orWhere('model', 'like', '%'.$keyword.'%')->where('business', $userId) 
            ->orWhere('error', 'like', '%'.$keyword.'%')->where('business', $userId)
            ->orWhere('imei', $keyword)->where('business', $userId)
            ->orderBy('id', 'DESC')->get();
            return view("Partner.search", ["devices" => $results, "partner" => $loggedInName, "keyword" => $keyword]);
        }elseif($accountType == "tech"){
            $results = Device::where('id', $keyword)
            ->orWhere('model', 'like', '%'.$keyword.'%')
            ->orWhere('error', 'like', '%'.$keyword.'%')
            ->orWhere('imei', $keyword)->where('business', $userId)
            ->orderBy('id', 'DESC')->get();
            return view("tech.search", ["devices" => $results, "partner" => $loggedInName, "keyword" => $keyword]);
       
        }
    }

    public function pdfShow($id){
        $device = Device::find($id);

        $business = $device->business;
        $customerData = User::where('id', $business)->get();
        return view("Partner.pdf", ["device" => $device, "customer" => $customerData]);
    }
}
