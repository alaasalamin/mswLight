<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use App\Models\Device;
use App\Models\Comment;
use App\Models\User;
use App\Models\MoonRepair;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
       
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $AccountType = Auth::user()->AccountType;
        $userId = Auth::user()->id;
        $loggedInName = Auth::user()->name;
        $activeDevices = Device::where("business", $userId)->orderBy("id", "DESC")->where("status", "!=", "finished")->get();
        $closedDevices = Device::where("business", $userId)->orderBy("id", "DESC")->where("status", "finished")->get();
        $comments = Comment::orderBy("id", "DESC")->get();                   
        
        if($AccountType == 'partner'){
            return view('Partner.home', ["partner" => $loggedInName, "activeDevices" => $activeDevices, "closedDevices" => $closedDevices, "notifications" => $comments]);
        }elseif($AccountType == 'admin'){
            $newDevices = Device::orderBy("id", "DESC")->where("status", "!=", "finished")->where("tech", NULL)->get();
            $activeDevices = Device::orderBy("id", "DESC")->where("status", "!=", "finished")->get();
            $techs = User::orderBy("name", "ASC")->where("AccountType", "tech")->get();
            return view("admin.home", ["admin" => $loggedInName, "activeDevices" => $activeDevices, "newDevices" => $newDevices, "techs" => $techs]);
        }elseif($AccountType == 'tech'){

            $loggedInName = Auth::user()->name;
            $newDevices = Device::orderBy("id", "DESC")->where("status", "!=", "finished")->where("tech", NULL)->get();
            $myDevices = Device::orderBy("id", "DESC")->where("status", "!=", "finished")->where("tech", $loggedInName)->get();

            $moonRepairDevices = MoonRepair::orderBy("id", "DESC")->where("status", "!=", "finished")->where("tech", NULL)->get();
            return view("Tech.home", ["tech" => $loggedInName, "newDevices" => $newDevices, "myDevices" => $myDevices, "moonRepairDevices" => $moonRepairDevices]);
        }elseif($AccountType == "b2c"){
            $loggedInName = Auth::user()->name;
             $newDevices = MoonRepair::orderBy("id", "DESC")->where("status", "open")->where("tech", Null)->get();
            return view("moonRepair.home", [
                "b2c" => $loggedInName,
                "newDevices" => $newDevices
            ]);
        }
        
    }
}
