<?php

namespace App\Http\Controllers;
use App\Models\Device;
use App\Models\Comment;
use Auth;
use Redirect;
use Illuminate\Http\Request;

class TechnikerController extends Controller
{
    //
    public function showDevice($id){
        $device = Device::find($id);
        $adminName = Auth::user()->name;
        $comments = Comment::where("deviceId", $id)->orderBy("id", "DESC")->get();
        return view("tech.device", ["admin" => $adminName, "device" => $device, "comments" => $comments]);
    }

    public function takeDevice($id){

        $loggedInName = Auth::user()->name;
        Device::where("id", $id)->update(array('tech' => $loggedInName));
        return redirect('../home/');
    }
}
