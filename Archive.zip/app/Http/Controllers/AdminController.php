<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Device;
use App\Models\Comment;
use App\Models\Brand;
use App\Models\User;
use Auth;
use Redirect;

class AdminController extends Controller
{
    //
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function showDevice($id){
        $device = Device::find($id);
        $adminName = Auth::user()->name;
        $comments = Comment::where("deviceId", $id)->orderBy("id", "DESC")->get();
        return view("admin.device", ["admin" => $adminName, "device" => $device, "comments" => $comments]);
    }

    public function updateDevice(Request $request, $id)
    {
        //
        $device = Device::find($id);
        $device->update($request->all());    
        
        $loggedInName = Auth::user()->name;  
        return redirect('admin/device/'.$id.'');

    }

    public function give($techWithId){
        $arr = explode('+', $techWithId);
        $tech = $arr[0];
        $deviceId = $arr[1];
        Device::where("id", $deviceId)->update(array('tech' => $tech));
        return redirect('home');
    }

    public function techsShow(){
        $techs = User::where("AccountType", "tech")->orderBy("id", "DESC")->get();
        $admin = Auth::user()->name;
        return view("admin.techs", ["admin" => $admin, "techs" => $techs]);
    }

    public function techDevices($id){
        $tech = User::find($id);
        $admin = Auth::user()->name;
        $techName = $tech->name;
        $devices = Device::where("tech", $techName)->where("status", "open")->orderBy("id", "DESC")->get();

        return view("admin.techDevices", ["admin" => $admin, "tech" => $techName, "devices" => $devices]);
    }

    public function destroyComment($id){
            Comment::destroy($id);
            return Redirect::back();
    }
    public function closeDevice($id){
            $device = Device::where("id", $id)->update(['status' => "finished"]);
            return Redirect::back();
    }
    public function openDevice($id){
            $device = Device::where("id", $id)->update(['status' => "open"]);
            return Redirect::back();
    }


    public function controlPanel(){
        $AccountType = Auth::user()->AccountType;
        if($AccountType == "admin"){

            $admin = Auth::user()->name;
            $brands = Brand::all();
            return view("admin.controlPanel", ["admin" => $admin, "brands" => $brands]);
        }else{
            return redirect('/');
        }
    }

    
}
